#!/bin/bash

# You could modify these environment variables to change the default constants
# DEFAULT_TRASH="/works/backup"

# 1. global variables
PATH='/works/shell:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin'
export PATH
# set -x
# First level directory
first_dir="/boot /root /usr /var /sbin /bin /etc /sys /proc"
# second_dir='/data /mnt'
# Define Color
green_color="\e[31;32m %-30s %-12s %35s\e[0m\n"
red_color="\e[31;31m %-30s %-12s %35s\e[0m\n"
# Fail to Mail
python_bin=`which python`
[ ! -e "$python_bin" ] && {
  echo "Python is not exsit, please install. For example: yum -y install python"
  exit 1
}
sendmail_bin='/works/shell/sendmail.py'
to_mail_list='ops@zerofinance.com'
DEFAULT_TRASH="/works/backup"
saferm_log="${DEFAULT_TRASH}/saferm.log"
SAFE_RM_TRASH=${SAFE_RM_TRASH:="$DEFAULT_TRASH"}
# Print debug info or not
# SAFE_RM_DEBUG=${SAFE_RM_DEBUG:=}
SAFE_RM_DEBUG=${SAFE_RM_DEBUG:=}
# 
# Simple basename: /bin/rm -> rm
COMMAND=${0##*/}
# pwd
CURRENT_DIR=$(pwd)

# make sure recycled bin exists
if [[ ! -e $SAFE_RM_TRASH ]]; then
  echo "Directory \"$SAFE_RM_TRASH\" does not exist, do you want create it?"
  echo -n "(yes/no): "
  read answer
  if [[ $answer = "yes" || ! -n $anwser ]]; then
    mkdir -p "$SAFE_RM_TRASH"
  else
    echo "Canceled!"
    exit 1
  fi
fi

# 2. define usage data_time debug send_to_mail
usage(){
  echo -e "Usage: rm [-f | -i | -I] [-dPRrvW] file ..."
  echo "       unlink file"````
  # if has an invalid option, exit with 1
  exit 1
}

if [[ "$#" = 0 ]]; then
  echo -e " Name: safe-rm"
  usage
fi

check_disk_size(){
  dirfile_size=`du -sm $1 |awk '{print $1}'`
  avail_disk=`df -m ${SAFE_RM_TRASH}|grep -v "Filesystem" | awk '{print $4}'`
  T=$(($avail_disk - $dirfile_size))
  if [ $T -gt 5000 ] ;then
    disk_radio=`echo "scale=2;${dirfile_size}/${avail_disk}" |bc|sed 's/\.//'`
    [ ${disk_radio} -ge 95 ] && {
      debug "Free disk space is more than ${disk_radio}% on volume ${SAFE_RM_TRASH}"
      send_to_mail "Free disk space is more than ${disk_radio}% on volume ${SAFE_RM_TRASH}"
      exit 1
    }
  else
    debug "no enough disk space,please free up some space and then try again."
    send_to_mail "No enough disk space (${T} < 5G) to use ${SAFE_RM_TRASH}"
    exit 1
  fi
}
# init base value
GUID=0
TIME=
# For change to file or directory from N to N-*
date_time(){
  TIME=$(date +%Y%m%d_%H%M%S)-$GUID
  (( GUID += 1 ))
}

# tools
debug(){
  if [[ -n "$SAFE_RM_DEBUG" ]]; then
    # echo "[D] $@" >&2
    echo "[D] $@" |& tee -a ${saferm_log}
  fi
}

send_to_mail(){
  echo "send to mail..."
  # local_ip=$(ip a|grep -E 'inet.*(eth0|ens)'| awk '{print $2}'|awk -F'/' '{print $1}'| head -1)
  # ${python_bin} ${sendmail_bin} "${to_mail_list}" "[Safe-to-RM]: [${1}]-$(date +%Y%m%d-%H%M%S)" "Time: [$(date '+%Y%m%d%T')]<br />From: [${local_ip}]." &>/dev/null
}

# 3. parse argv 
ARG_END=
FILE_NAME=
ARG=
file_i=0
arg_i=0

invalid_option(){
  # if there's an invalid option, `rm` only takes the second char of the option string
  # case:
  # rm -c
  # -> rm: illegal option -- c
  echo "rm: illegal option -- ${1:1:1}"
  usage
}

split_push_arg(){
  # remove leading '-' and split combined short options
  # -vif -> vif -> v, i, f
  split=`echo ${1:1} | fold -w1`

  local arg
  for arg in ${split[@]}; do
    ARG[arg_i]="-$arg"
    ((arg_i += 1))
  done
}

push_arg(){
  ARG[arg_i]=$1
  ((arg_i += 1))
}

push_file(){
  FILE_NAME[file_i]=$1
  ((file_i += 1))
}

# pre-parse argument vector
while [[ -n $1 ]]; do
  # case:
  # rm -v abc -r --force
  # -> -r will be ignored
  # -> args: ['-v'], files: ['abc', '-r', 'force']
  if [[ -n $ARG_END ]]; then
    push_file "$1"
  else
    case $1 in
    # case:
    # rm -v -f -i a b
    # case:
    # rm -vf -ir a b
    # ATTENTION:
    # Regex in bash is not perl regex,
    # in which `'*'` means "anything" (including nothing)
    -[a-zA-Z]*)
      split_push_arg $1; debug "short option $1"
      ;;
    # rm --force a
    --[a-zA-Z]*)
      push_arg $1; debug "option $1"
      ;;
    # rm -- -a
    --)
      ARG_END=1; debug "divider"
      ;;
    # case:
    # rm -
    # -> args: [], files: ['-']
    *)
      push_file "$1"; debug "file $1"
      ARG_END=1
      ;;
    esac
  fi
  shift
done

# 4. define flags 
OPT_FORCE=
OPT_INTERACTIVE=
OPT_INTERACTIVE_ONCE=
OPT_RECURSIVE=
OPT_VERBOSE=
# global exit code, default to 0
EXIT_CODE=0
# parse options
for arg in ${ARG[@]}; do
  case $arg in
  # There's no --help|-h option for rm on Mac OS
  # [hH]|--[hH]elp)
  # help
  # shift
  # ;;

  -f|--force)
    OPT_FORCE=1;        debug "force        : $arg"
    ;;
  # interactive=always
  -i|--interactive|--interactive=always)
    OPT_INTERACTIVE=1;  debug "interactive  : $arg"
    OPT_INTERACTIVE_ONCE=
    ;;
  # interactive=once. interactive=once and interactive=always are exclusive
  -I|--interactive=once)
    OPT_INTERACTIVE_ONCE=1;  debug "interactive_once  : $arg"
    OPT_INTERACTIVE=;
    ;;
  # both r and R is allowed
  -[rR]|--[rR]ecursive)
    OPT_RECURSIVE=1;    debug "recursive    : $arg"
    ;;
  # only lowercase v is allowed
  -v|--verbose)
    OPT_VERBOSE=1;      debug "verbose      : $arg"
    ;;
  *)
    invalid_option $arg
    ;;
  esac
done

# 5. try to remove a file or directory
# define remove + recursive_remove + trash + list_files
remove(){
  local file=$1
  # don't delete first directory
  for dir in ${first_dir};do
    # for current directory
    new_vars=`echo ${file}| sed 's/^\.\///g'`
    new_dirname=`echo $(pwd)/${new_vars} |sed 's#///#/#g'|sed 's#//#/#g'`
    [ ! -e ${new_dirname} ] && new_dirname="${file}"
    case ${new_dirname} in
      ${SAFE_RM_TRASH}|${SAFE_RM_TRASH}/|${SAFE_RM_TRASH}/*)
        echo -e "Don't allow delete backup directory or any files of this direcrory."
        send_to_mail "Don't allow delete backup directory or any files of this direcrory (${file})"
        exit 1
        ;;
      ${dir}|${dir}/|${dir}/*)
        echo -e "don't allow delete first level directory or any files of this direcrory."
        send_to_mail "Don't allow delete first level directory or any files of this direcrory (${file})"
        exit 1
        ;;
    esac

    # 
    [ ! -d "${new_dirname}" ] && {
      echo ${new_dirname} | grep '/works/backup'
      [ $? -eq 0 ] && {
        echo -e "don't allow delete any files in backup directory."
        send_to_mail "Don't allow delete any files in backup directory.(${file})"
        exit 1
      }
    }
  done
  # check disk 
  check_disk_size "${file}"
  # if is dir
  if [[ -d $file ]]; then
    # if a directory, and without '-r' option
    if [[ ! -n $OPT_RECURSIVE ]]; then
      debug "$LINENO: $file: is a directory"
      echo "$COMMAND: $file: is a directory"
      return 1
    fi

    if [[ $file = './' ]]; then
      echo "$COMMAND: $file: Invalid argument"
      return 1
    fi

    if [[ $OPT_INTERACTIVE = 1 ]]; then
      echo -n "examine files in directory $file? "
      read answer
      # actually, as long as the answer start with 'y', the file will be removed
      # default to no remove
      if [[ ${answer:0:1} =~ [yY] ]]; then
        # if choose to examine the dir, recursively check files first
        recursive_remove "$file"
        # interact with the dir at last
        echo -n "remove $file? "
        read answer
        if [[ ${answer:0:1} =~ [yY] ]]; then
          [[ $(ls -A "$file") ]] && {
            echo "$COMMAND: $file: Directory not empty"
            return 1
          } || {
            trash "$file"
            debug "$LINENO: trash returned status $?"
          }
        fi
      fi
    else
      trash "$file"
      debug "$LINENO: trash returned status $?"
    fi
    # if is a file
  else
    if [[ "$OPT_INTERACTIVE" = 1 ]]; then
      echo -n "remove $file? "
      read answer
      if [[ ${answer:0:1} =~ [yY] ]]; then
        :
      else
        return 0
      fi
    fi
    trash "$file"
    debug "$LINENO: trash returned status $?"
  fi
}

recursive_remove(){
  local path

  # use `ls -A` instead of `for` to list hidden files.
  # and `for $1/*` is also weird if `$1` is neithor a dir nor existing that will print "$1/*" directly and rudely.
  # never use `find $1`, for the searching order is not what we want
  local list=$(ls -A "$1")

  [[ -n $list ]] && for path in "$list"; do
    remove "$1/$path"
  done
}

# trash a file or dir directly
trash(){
  debug "trash $1"

  # origin file path
  local file=$1

  # the first parameter to be passed to `mv`
  local move=$file
  local base=$(basename "$file")
  local travel=

  # basename ./       -> .
  # basename ../      -> ..
  # basename ../abc   -> abc
  # basename ../.abc  -> .abc
  if [[ -d "$file" && ${base:0:1} = '.' ]]; then
    # then file must be a relative dir
    cd $file
    # pwd can't be piped?
    move=$(pwd)
    move=$(basename "$move")
    cd ..
    travel=1
  fi

  local trash_name=$SAFE_RM_TRASH/$base

  # if already in the trash
  if [[ -e "$trash_name" ]]; then
    # renew $TIME
    date_time
    trash_name="$trash_name-$TIME"
  fi
  [[ "$OPT_VERBOSE" = 1 ]] && list_files "$file"
  # debug "mv $move to $trash_name"
  mv "$move" "$trash_name"
  [ $? -eq 0 ] && printf "${green_color}" "[mv][$new_dirname]" "......" "[$trash_name]" >> ${saferm_log}
  # echo "[$move] .... [$trash_name] .... [OK]"
  [[ "$travel" = 1 ]] && cd $CURRENT_DIR &> /dev/null
  #default status
  return 0
}

# list all files and maintain outward sequence
# we can't just use `find $file`, 'coz `find` act a inward searching, unlike rm -v
list_files(){
  if [[ -d "$1" ]]; then
    local list=$(ls -A "$1")
    local f

    [[ -n $list ]] && for f in "$list"; do
      list_files "$1/$f"
    done
  fi
  echo $1
}

# 6. debug: get $FILE_NAME array length
debug "${#FILE_NAME[@]} files or directory to process: ${FILE_NAME[@]}"

# test remove interactive_once: ask for 3 or more files or with recorsive option
if [[ (${#FILE_NAME[@]} > 2 || $OPT_RECURSIVE = 1) && $OPT_INTERACTIVE_ONCE = 1 ]]; then
  echo -n "$COMMAND: remove all arguments? "
  read answer
  # actually, as long as the answer start with 'y', the file will be removed
  # default to no remove
  if [[ ! ${answer:0:1} =~ [yY] ]]; then
    debug "EXIT_CODE $EXIT_CODE"
    exit $EXIT_CODE
  fi
fi

for file in "${FILE_NAME[@]}"; do
  debug "result file $file"
  if [[ $file = "/" ]]; then
    echo "it is dangerous to operate recursively on /"
    send_to_mail "It is dangerous to operate (rm) recursively on ${file}"
    # echo "are you insane?"
    EXIT_CODE=1
    # Exit immediately
    debug "EXIT_CODE $EXIT_CODE"
    exit $EXIT_CODE
  fi

  if [[ $file = "." || $file = ".." ]]; then
    echo "$COMMAND: \".\" and \"..\" may not be removed"
    EXIT_CODE=1
    continue
  fi

  #the same check also apply on /. /..
  if [[ $(basename $file) = "." || $(basename $file) = ".." ]]; then
    echo "$COMMAND: \".\" and \"..\" may not be removed"
    EXIT_CODE=1
    continue
  fi

  # deal with wildcard and also, redirect error output
  ls_result=$(ls -d "$file" 2> /dev/null)

  # debug
  debug "ls_result: $ls_result"

  if [[ -n "$ls_result" ]]; then
    for file in "$ls_result"; do
      remove "$file"
      status=$?
      debug "remove returned status: $status"

      if [[ ! $status == 0 ]]; then
        EXIT_CODE=1
      fi
    done
  else
    echo "$COMMAND: $file: No such file or directory"
    EXIT_CODE=1
  fi
done

debug "EXIT_CODE $EXIT_CODE"
exit $EXIT_CODE
# End
