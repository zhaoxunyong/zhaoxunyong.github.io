#!/bin/bash

apt-get -y install apt-transport-https ca-certificates software-properties-common
curl -fsSL http://mirrors.aliyun.com/docker-ce/linux/ubuntu/gpg | apt-key add -
add-apt-repository "deb [arch=amd64] http://mirrors.aliyun.com/docker-ce/linux/ubuntu $(lsb_release -cs) stable" -y
apt-get -y update
apt-get install docker-ce docker-ce-cli containerd.io docker-compose-plugin -y

gpasswd -a dev docker
chown dev.dev /var/run/docker.sock