#!/bin/bash


curl -XPOST http://127.0.0.1:9093/-/reload
