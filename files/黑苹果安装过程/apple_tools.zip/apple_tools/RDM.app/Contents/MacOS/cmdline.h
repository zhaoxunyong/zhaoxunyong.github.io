

int cmdline_main(int argc, const char * argv[]);
